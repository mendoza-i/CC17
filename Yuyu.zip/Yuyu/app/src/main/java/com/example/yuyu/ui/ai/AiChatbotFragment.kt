package com.example.yuyu.ui.ai

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.yuyu.databinding.FragmentAiChatbotBinding

class AiChatbotFragment : Fragment() {

    private var _binding: FragmentAiChatbotBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val aiChatbotViewModel =
            ViewModelProvider(this).get(AiChatbotViewModel::class.java)

        _binding = FragmentAiChatbotBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textAiChatbot
        aiChatbotViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
