package com.example.yuyu.ui.ai

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AiChatbotViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Hi! I’m Yuyu, your personal health coach. I’m here to help you manage your PCOS journey, one step at a time."
    }
    val text: LiveData<String> = _text
}
