package com.example.yuyu.ui.ai

data class Message(
    val text: String,
    val isUser: Boolean
)
