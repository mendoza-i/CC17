package com.example.yuyu.ui.ai

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.yuyu.databinding.FragmentAiChatbotBinding
import org.json.JSONObject
import java.io.BufferedReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import androidx.core.view.WindowInsetsCompat.Type as InsetsType

class AiChatbotFragment : Fragment() {

    private var _binding: FragmentAiChatbotBinding? = null
    private val binding get() = _binding!!

    private val messages = mutableListOf<Message>()
    private lateinit var adapter: ChatAdapter

    // Emotional support personality context
    private val assistantContext = """
        You are Yuyu, an understanding emotional support companion for women with PCOS.
        Share short tips for their concerns if they specifically asked for it.
        Tailor everything to PCOS, even making ingredients, it should be healthy for PCOS.
        Never diagnose or prescribe, just give gentle encouragement and emotional comfort.
        Make your responses short but expand if the user wants.
        Never repeat greetings after the first one.
    """.trimIndent()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAiChatbotBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ChatAdapter(messages)
        val layoutManager = LinearLayoutManager(requireContext()).apply {
            stackFromEnd = true
        }
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.adapter = adapter
        binding.recyclerView.clipToPadding = false

        binding.buttonSend.setOnClickListener {
            val userText = binding.textInput.text.toString().trim()
            if (userText.isNotEmpty()) {
                sendMessage(userText)
                binding.textInput.text.clear()
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val imeInsets = insets.getInsets(InsetsType.ime())
            val navInsets = insets.getInsets(InsetsType.navigationBars())
            val bottomPadding = imeInsets.bottom.coerceAtLeast(navInsets.bottom)
            binding.recyclerView.updatePadding(bottom = bottomPadding)
            binding.messageContainer.updatePadding(bottom = navInsets.bottom)
            if (imeInsets.bottom > 0) {
                val count = adapter.itemCount
                if (count > 0) binding.recyclerView.post {
                    binding.recyclerView.scrollToPosition(count - 1)
                }
            }
            insets
        }
    }

    private fun sendMessage(userText: String) {
        addMessage(userText, true)
        addMessage("Thinking...", false)

        val apiKey = "AIzaSyAW7_3vIySH7-GY5TYvhypzLTA2xC_8r_E"
        val model = "models/gemini-2.5-flash"
        val url = "https://generativelanguage.googleapis.com/v1beta/$model:generateContent?key=$apiKey"

        val jsonBody = """
            {
              "contents": [{
                "parts": [
                  {"text": "$assistantContext"},
                  {"text": "$userText"}
                ]
              }]
            }
        """.trimIndent()

        Thread {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true

                OutputStreamWriter(connection.outputStream).use { it.write(jsonBody) }

                val responseCode = connection.responseCode
                val responseText = if (responseCode == 200) {
                    BufferedReader(connection.inputStream.reader()).use { it.readText() }
                } else {
                    BufferedReader(connection.errorStream.reader()).use { it.readText() }
                }

                Log.d("GeminiAPI", "Response ($responseCode): $responseText")

                val aiReply = try {
                    val json = JSONObject(responseText)
                    json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                } catch (e: Exception) {
                    Log.e("GeminiAPI", "Parsing error: ${e.message}")
                    "I couldn’t understand that. Please try again."
                }

                requireActivity().runOnUiThread {
                    updateLastMessage(aiReply)
                }

            } catch (e: Exception) {
                Log.e("GeminiAPI", "Error: ${e.message}", e)
                requireActivity().runOnUiThread {
                    updateLastMessage("Error: ${e.message}")
                }
            }
        }.start()
    }

    private fun addMessage(text: String, isUser: Boolean) {
        messages.add(Message(text, isUser))
        adapter.notifyItemInserted(messages.size - 1)
        binding.recyclerView.scrollToPosition(messages.size - 1)
    }

    private fun updateLastMessage(newText: String) {
        if (messages.isNotEmpty()) {
            val lastIndex = messages.size - 1
            messages[lastIndex] = Message(newText, false)
            adapter.notifyItemChanged(lastIndex)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
